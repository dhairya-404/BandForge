(function() {
  "use strict";
  const api = globalThis.browser ?? chrome;
  const BRIDGE_PORTS = [19288, 19289, 19290];
  const BRIDGE_API = 1;
  const BRIDGE_DEADLINE_MS = 8e3;
  let found = null;
  async function ask(port) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/ping`, {
        signal: AbortSignal.timeout(1500)
      });
      const ping = await response.json();
      if (!response.ok || ping.app !== "plexo") return "closed";
      return ping.api === BRIDGE_API ? "ok" : "update";
    } catch {
      return "closed";
    }
  }
  async function reach() {
    const answers = await Promise.all(BRIDGE_PORTS.map(ask));
    const at = answers.indexOf("ok");
    found = at >= 0 ? BRIDGE_PORTS[at] : null;
    return at >= 0 ? "ok" : answers.includes("update") ? "update" : "closed";
  }
  async function send(request) {
    if (await reach() !== "ok" || found === null) return "closed";
    const port = found;
    try {
      const response = await fetch(`http://127.0.0.1:${port}/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(request),
        // Past Plexo's own deadline: Plexo answers nothing once this has given up.
        signal: AbortSignal.timeout(BRIDGE_DEADLINE_MS + 2e3)
      });
      if (!response.ok) return "kept";
      const { token } = await response.json();
      return { port, token };
    } catch (error) {
      return error instanceof DOMException && error.name === "TimeoutError" ? "kept" : "closed";
    }
  }
  async function confirm({ port, token }) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
        signal: AbortSignal.timeout(3e3)
      });
      return response.ok;
    } catch {
      return false;
    }
  }
  function storeOf(source) {
    return source.cookieStoreId ?? (source.incognito ? "1" : void 0);
  }
  function hostOf(url) {
    try {
      return url ? [new URL(url).hostname] : [];
    } catch {
      return [];
    }
  }
  async function browserContext(urls, storeId, referer) {
    const cookies = /* @__PURE__ */ new Map();
    const hosts = [...urls, referer].flatMap(hostOf);
    for (const url of new Set(urls)) {
      if (!url || !/^https?:/i.test(url)) continue;
      const found2 = await api.cookies.getAll({ url, storeId }).catch(async () => {
        const all = await api.cookies.getAll({
          url,
          storeId,
          firstPartyDomain: null
        });
        return all.filter(({ firstPartyDomain: site }) => {
          return !site || hosts.some((host) => host === site || host.endsWith(`.${site}`));
        });
      }).catch(() => []);
      for (const { name, value, domain, hostOnly, path, secure } of found2) {
        cookies.set(`${domain}
${path}
${name}`, { name, value, domain, hostOnly, path, secure });
      }
    }
    return {
      cookies: [...cookies.values()],
      ...referer && /^https?:/i.test(referer) && { referer },
      userAgent: navigator.userAgent,
      name: browserName()
    };
  }
  function browserName() {
    const agent = navigator.userAgent;
    if (/Firefox\//.test(agent)) return "Firefox";
    if (/Edg\//.test(agent)) return "Edge";
    if (/OPR\//.test(agent)) return "Opera";
    if (/Vivaldi\//.test(agent)) return "Vivaldi";
    if ("brave" in navigator) return "Brave";
    return "Chrome";
  }
  async function wake() {
    const tab = await api.tabs.create({ url: "plexo://open" });
    let reached = false;
    for (let tries = 0; tries < 20 && !reached; tries++) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      reached = await reach() === "ok";
    }
    if (reached && tab.id !== void 0) await api.tabs.remove(tab.id).catch(() => {
    });
    return reached;
  }
  const DEFAULTS = {
    capture: true,
    sites: [],
    skipSmall: false,
    minMegabytes: 1,
    browserBonding: false
  };
  async function loadSettings() {
    return { ...DEFAULTS, ...await api.storage.local.get(DEFAULTS) };
  }
  function excluded(sites, urls) {
    return urls.some((url) => {
      if (!url) return false;
      let host;
      try {
        host = new URL(url).hostname;
      } catch {
        return false;
      }
      return sites.some((site) => host === site || host.endsWith(`.${site}`));
    });
  }
  const MENU_ID = "download-with-plexo";
  const CHECK_ALARM = "check-plexo";
  const openedAt = /* @__PURE__ */ new Map();
  const ICON = { 16: "icons/icon-16.png", 32: "icons/icon-32.png" };
  const ICON_OFF = { 16: "icons/icon-off-16.png", 32: "icons/icon-off-32.png" };
  async function syncProxyState() {
    const { browserBonding } = await loadSettings();
    if (typeof chrome !== "undefined" && chrome.proxy) {
      if (browserBonding) {
        chrome.proxy.settings.set(
          {
            value: {
              mode: "pac_script",
              pacScript: { url: "http://127.0.0.1:9091/proxy.pac" }
            },
            scope: "regular"
          },
          () => {
            console.log("[Tesso Extension] Chrome proxy configured for Multi-WAN bonding.");
          }
        );
      } else {
        chrome.proxy.settings.clear({ scope: "regular" }, () => {
          console.log("[Tesso Extension] Chrome proxy reverted to direct.");
        });
      }
    }
  }
  async function showState(reached) {
    const { capture: capture2, browserBonding } = await loadSettings();
    reached ??= await reach();
    const title = !capture2 ? "Tesso: capture is off" : reached === "closed" ? "Tesso isn’t open: downloads stay in the browser" : reached === "update" ? "Update Tesso to use this extension" : browserBonding ? "Tesso: Multi-WAN Browser Acceleration Active ⚡" : "Tesso";
    await api.action.setIcon({ path: capture2 && reached === "ok" ? ICON : ICON_OFF });
    await api.action.setTitle({ title });
    if (typeof api.action.setBadgeText === "function") {
      await api.action.setBadgeText({ text: browserBonding ? "⚡" : "" });
      if (typeof api.action.setBadgeBackgroundColor === "function") {
        await api.action.setBadgeBackgroundColor({ color: "#0ea5e9" });
      }
    }
  }
  async function capture(item) {
    const settings = await loadSettings();
    const url = item.finalUrl || item.url;
    if (!settings.capture || !/^https?:/i.test(url)) return false;
    if (excluded(settings.sites, [item.url, item.finalUrl, item.referrer])) return false;
    const request = {
      url,
      browser: await browserContext([item.url, item.finalUrl], storeOf(item), item.referrer),
      pageUrl: item.referrer || void 0,
      minBytes: settings.skipSmall ? settings.minMegabytes * 1024 * 1024 : void 0,
      // Chrome and Firefox both give a path here.
      fileName: item.filename.split(/[\\/]/).pop() || void 0
    };
    const handoff = await send(request);
    if (typeof handoff === "string") {
      if (handoff === "closed") await showState("closed");
      return false;
    }
    await api.downloads.cancel(item.id).catch(() => {
    });
    const [after] = await api.downloads.search({ id: item.id }).catch(() => []);
    if (after?.state === "complete") return false;
    await api.downloads.erase({ id: item.id }).catch(() => {
    });
    const shown = await confirm(handoff);
    await closeEmptyTab([item.url, item.finalUrl]);
    await showState(shown ? "ok" : void 0);
    return true;
  }
  async function closeEmptyTab(urls) {
    const recently = Date.now() - 3e4;
    for (const tab of await api.tabs.query({})) {
      const shows = tab.pendingUrl ?? tab.url;
      if (tab.id === void 0 || shows === void 0 || !urls.includes(shows)) continue;
      if ((openedAt.get(tab.id) ?? 0) < recently) continue;
      await api.tabs.remove(tab.id).catch(() => {
      });
    }
  }
  const determining = api.downloads.onDeterminingFilename;
  if (determining) {
    determining.addListener((item, suggest) => {
      void capture(item).then((taken) => taken || suggest());
      return true;
    });
  } else {
    api.downloads.onCreated.addListener((item) => void capture(item));
  }
  async function sendLink(info, tab) {
    const url = info.linkUrl;
    if (!url) return;
    const request = /^magnet:/i.test(url) ? { url } : {
      url,
      browser: await browserContext([url], tab && storeOf(tab), info.pageUrl),
      pageUrl: info.pageUrl
    };
    let sent = await send(request);
    if (sent === "closed" && await wake()) sent = await send(request);
    const shown = typeof sent !== "string" && await confirm(sent);
    await showState(shown ? "ok" : void 0);
  }
  function setUp() {
    createMenu();
    void syncProxyState();
    void api.alarms.create(CHECK_ALARM, { periodInMinutes: 0.5 });
    void showState();
  }
  function createMenu() {
    void api.contextMenus.removeAll().then(
      () => api.contextMenus.create({ id: MENU_ID, title: "Download with Tesso", contexts: ["link"] })
    );
  }
  api.runtime.onInstalled.addListener(setUp);
  api.runtime.onStartup.addListener(setUp);
  api.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === CHECK_ALARM) void showState();
  });
  api.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === MENU_ID) void sendLink(info, tab);
  });
  api.tabs.onCreated.addListener((tab) => {
    if (tab.id !== void 0) openedAt.set(tab.id, Date.now());
  });
  api.storage.onChanged.addListener(() => {
    void syncProxyState();
    void showState();
  });
  api.runtime.onMessage.addListener((message) => {
    const { wakePlexo, checkPlexo } = message;
    if (checkPlexo) void showState();
    if (wakePlexo) void wake().then((woke) => showState(woke ? "ok" : "closed"));
  });
})();
