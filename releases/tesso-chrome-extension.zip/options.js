(function() {
  "use strict";
  const api = globalThis.browser ?? chrome;
  const BRIDGE_PORTS = [19288, 19289, 19290];
  const BRIDGE_API = 1;
  let found = null;
  async function ask(port) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/ping`, {
        signal: AbortSignal.timeout(1500)
      });
      const ping = await response.json();
      if (!response.ok || ping.app !== "plexo") return "closed";
      return ping.api === BRIDGE_API ? "ok" : "update";
    } catch {
      return "closed";
    }
  }
  function plexoPort() {
    return found;
  }
  async function reach() {
    const answers = await Promise.all(BRIDGE_PORTS.map(ask));
    const at = answers.indexOf("ok");
    found = at >= 0 ? BRIDGE_PORTS[at] : null;
    return at >= 0 ? "ok" : answers.includes("update") ? "update" : "closed";
  }
  const DEFAULTS = {
    capture: true,
    sites: [],
    skipSmall: false,
    minMegabytes: 1,
    browserBonding: false
  };
  async function loadSettings() {
    return { ...DEFAULTS, ...await api.storage.local.get(DEFAULTS) };
  }
  function saveSettings(patch) {
    return api.storage.local.set(patch);
  }
  function siteOf(input) {
    const text = input.trim().toLowerCase().replace(/^\*\./, "");
    try {
      const host = new URL(/^[a-z]+:\/\//.test(text) ? text : `https://${text}`).hostname;
      return host.includes(".") || host === "localhost" ? host : null;
    } catch {
      return null;
    }
  }
  const element = (id) => document.getElementById(id);
  async function render() {
    const settings = await loadSettings();
    element("capture").checked = settings.capture;
    element("skip-small").checked = settings.skipSmall;
    const minimum = element("min-mb");
    minimum.value = String(settings.minMegabytes);
    minimum.disabled = !settings.skipSmall;
    const list = element("sites");
    list.replaceChildren(
      ...settings.sites.map((site) => {
        const item = document.createElement("li");
        const name = document.createElement("span");
        name.textContent = site;
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "ghost";
        remove.textContent = "Remove";
        remove.setAttribute("aria-label", `Remove ${site}`);
        remove.addEventListener("click", () => {
          void saveSettings({ sites: settings.sites.filter((other) => other !== site) });
        });
        item.append(name, remove);
        return item;
      })
    );
    element("no-sites").hidden = settings.sites.length > 0;
  }
  async function renderConnection() {
    const reached = await reach();
    element("dot").className = `dot ${reached === "ok" ? "ok" : reached === "update" ? "warn" : ""}`;
    element("connection").textContent = reached === "ok" ? "Connected to Plexo" : reached === "update" ? "Update Plexo to use this extension" : "Plexo isn’t open";
    element("open-plexo").hidden = reached !== "closed";
    const port = plexoPort();
    element("port").textContent = port === null ? "" : `127.0.0.1:${port}`;
  }
  element("capture").addEventListener("change", (event) => {
    void saveSettings({ capture: event.target.checked });
  });
  element("skip-small").addEventListener("change", (event) => {
    void saveSettings({ skipSmall: event.target.checked });
  });
  element("min-mb").addEventListener("change", (event) => {
    const megabytes = Math.round(Number(event.target.value));
    if (megabytes >= 1) void saveSettings({ minMegabytes: megabytes });
    else void render();
  });
  element("add-site").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = element("site");
    const site = siteOf(input.value);
    element("site-error").hidden = site !== null || input.value.trim() === "";
    if (!site) return;
    const { sites } = await loadSettings();
    if (!sites.includes(site)) await saveSettings({ sites: [...sites, site] });
    input.value = "";
  });
  element("open-plexo").addEventListener("click", () => {
    void api.runtime.sendMessage({ wakePlexo: true }).then(() => setTimeout(renderConnection, 4e3));
  });
  element("version").textContent = `Extension ${api.runtime.getManifest().version}`;
  api.storage.onChanged.addListener(() => void render());
  void render();
  void renderConnection();
})();
