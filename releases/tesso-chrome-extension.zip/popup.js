(function() {
  "use strict";
  const api = globalThis.browser ?? chrome;
  const BRIDGE_PORTS = [19288, 19289, 19290];
  const BRIDGE_API = 1;
  async function ask(port) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/ping`, {
        signal: AbortSignal.timeout(1500)
      });
      const ping = await response.json();
      if (!response.ok || ping.app !== "plexo") return "closed";
      return ping.api === BRIDGE_API ? "ok" : "update";
    } catch {
      return "closed";
    }
  }
  async function reach() {
    const answers = await Promise.all(BRIDGE_PORTS.map(ask));
    const at = answers.indexOf("ok");
    return at >= 0 ? "ok" : answers.includes("update") ? "update" : "closed";
  }
  const DEFAULTS = {
    capture: true,
    sites: [],
    skipSmall: false,
    minMegabytes: 1,
    browserBonding: false
  };
  async function loadSettings() {
    return { ...DEFAULTS, ...await api.storage.local.get(DEFAULTS) };
  }
  function saveSettings(patch) {
    return api.storage.local.set(patch);
  }
  function excluded(sites, urls) {
    return urls.some((url) => {
      if (!url) return false;
      let host;
      try {
        host = new URL(url).hostname;
      } catch {
        return false;
      }
      return sites.some((site) => host === site || host.endsWith(`.${site}`));
    });
  }
  const element = (id) => document.getElementById(id);
  const ALL_SITES = { origins: ["<all_urls>"] };
  async function activeHost() {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    return tab?.url && /^https?:/i.test(tab.url) ? new URL(tab.url).hostname : null;
  }
  async function render() {
    const [settings, host, reached, access] = await Promise.all([
      loadSettings(),
      activeHost(),
      reach(),
      // Firefox lets the user withhold site access, which reading a site's cookies needs.
      api.permissions.contains(ALL_SITES)
    ]);
    const [tone, text] = reached === "closed" ? ["", "Tesso not open"] : reached === "update" ? ["warn", "Update Tesso"] : settings.capture ? ["ok", "Connected"] : ["", "Capture off"];
    element("status-dot").className = `dot ${tone}`;
    element("status-text").textContent = text;
    element("access").hidden = access;
    element("closed").hidden = reached !== "closed";
    element("browserBonding").checked = settings.browserBonding;
    element("bonding-hint").textContent = settings.browserBonding ? "All Chrome tabs routed over bonded multi-network links ⚡" : "Direct single-network connection";
    element("capture").checked = settings.capture;
    element("capture-hint").textContent = settings.capture ? "Downloads open in Tesso instead of the browser." : "Downloads stay in the browser.";
    element("site-row").hidden = host === null;
    if (host) {
      const on = !excluded(settings.sites, [`https://${host}/`]);
      const site = element("site");
      site.checked = on && settings.capture;
      site.disabled = !settings.capture;
      element("site-host").textContent = host;
      element("site-hint").textContent = !settings.capture ? "Capture is off everywhere." : on ? "Downloads from this site go to Tesso." : "Downloads from this site stay in the browser.";
    }
  }
  element("browserBonding").addEventListener("change", (event) => {
    void saveSettings({ browserBonding: event.target.checked });
  });
  element("capture").addEventListener("change", (event) => {
    void saveSettings({ capture: event.target.checked });
  });
  element("site").addEventListener("change", async (event) => {
    const host = await activeHost();
    if (!host) return;
    const { sites } = await loadSettings();
    const covering = (site) => host === site || host.endsWith(`.${site}`);
    await saveSettings({
      sites: event.target.checked ? sites.filter((site) => !covering(site)) : [...sites, host]
    });
  });
  element("grant").addEventListener("click", () => {
    void api.permissions.request(ALL_SITES).then(render);
  });
  element("open-plexo").addEventListener("click", () => {
    void api.runtime.sendMessage({ wakePlexo: true });
  });
  element("options").addEventListener("click", () => void api.runtime.openOptionsPage());
  api.storage.onChanged.addListener(() => void render());
  void render();
  void api.runtime.sendMessage({ checkPlexo: true }).catch(() => {
  });
})();
